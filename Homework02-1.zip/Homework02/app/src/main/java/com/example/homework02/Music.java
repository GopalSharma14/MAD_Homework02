package com.example.homework02;

import java.util.Date;

public class Music {
    String track_name;
    String genre;
    String artist;
    String album;
    double track_price;
    double album_price;
    Date release_date;


    public Music(String track_name, String genre, String artist, String album, double track_price, double album_price) {
        this.track_name = track_name;
        this.genre = genre;
        this.artist = artist;
        this.album = album;
        this.track_price = track_price;
        this.album_price = album_price;
    }

    @Override
    public String toString() {
        return "Music{" +
                "track_name='" + track_name + '\'' +
                ", genre='" + genre + '\'' +
                ", artist='" + artist + '\'' +
                ", album='" + album + '\'' +
                ", track_price=" + track_price +
                ", album_price=" + album_price +
                '}';
    }

}
