package com.example.homework02;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.ViewHolder> {

    ArrayList<Music> mData = new ArrayList<>();

    public MusicAdapter(ArrayList<Music> mData) {
        this.mData = mData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.music_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Music music = mData.get(position);

        holder.artist_tv.setText(music.artist);
        holder.track_tv.setText(music.track_name);
        holder.price_tv.setText(Double.toString(music.track_price));
        holder.date_tv.setText((CharSequence) music.release_date);
        holder.music = music;
    }

    @Override
    public int getItemCount() {
        return this.mData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView artist_tv, track_tv, price_tv, date_tv;
        Music music;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            artist_tv = itemView.findViewById(R.id.artist_tv);
            track_tv = itemView.findViewById(R.id.track_tv);
            price_tv = itemView.findViewById(R.id.price_tv);
            date_tv = itemView.findViewById(R.id.date_tv);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("demo", "clicked" + music.artist + " " + music.track_name);
                }
            });
        }
    }
}
